import 'package:flutter/material.dart';

class GridViewTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 4.0,
        mainAxisSpacing: 4.0,
      ),
      itemCount: 20,
      itemBuilder: (context, index) {
        return GestureDetector(
          onTap: () {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Tapped on Grid Item ${index + 1}'),
                duration: Duration(seconds: 1),
              ),
            );
          },
          child: Card(
            elevation: 4,
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.ac_unit, size: 40, color: Colors.blue),
                  SizedBox(height: 8),
                  Text('Item ${index + 1}'),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
